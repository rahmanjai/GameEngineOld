/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTPackedFloat {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of TexImage1D,
	 *  TexImage2D, TexImage3D, CopyTexImage1D, CopyTexImage2D, and
	 *  RenderbufferStorage:
	 */
	public static final int GL_R11F_G11F_B10F_EXT = 0x8C3A;

	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels,
	 *  TexImage1D, TexImage2D, GetTexImage, TexImage3D, TexSubImage1D,
	 *  TexSubImage2D, TexSubImage3D:
	 */
	public static final int GL_UNSIGNED_INT_10F_11F_11F_REV_EXT = 0x8C3B;

	/**
	 * Accepted by the &lt;pname&gt; parameters of GetIntegerv and GetFloatv: 
	 */
	public static final int GL_RGBA_SIGNED_COMPONENTS_EXT = 0x8C3C;

	private EXTPackedFloat() {}
}
