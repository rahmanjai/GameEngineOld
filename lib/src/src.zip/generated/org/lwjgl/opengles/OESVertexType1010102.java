/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESVertexType1010102 {

	/**
	 * Accepted by the &lt;type&gt; parameter of VertexAttribPointer 
	 */
	public static final int GL_UNSIGNED_INT_10_10_10_2_OES = 0x8DF6,
		GL_INT_10_10_10_2_OES = 0x8DF7;

	private OESVertexType1010102() {}
}
