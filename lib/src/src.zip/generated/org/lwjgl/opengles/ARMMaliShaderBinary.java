/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class ARMMaliShaderBinary {

	/**
	 * Accepted by the &lt;binaryFormat&gt; parameter of ShaderBinary: 
	 */
	public static final int GL_MALI_SHADER_BINARY_ARM = 0x8F60;

	private ARMMaliShaderBinary() {}
}
