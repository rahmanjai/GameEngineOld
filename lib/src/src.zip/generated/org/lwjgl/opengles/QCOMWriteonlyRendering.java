/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class QCOMWriteonlyRendering {

	/**
	 * Accepted by the &lt;cap&gt; parameter of Enable, Disable. 
	 */
	public static final int GL_WRITEONLY_RENDERING_QCOM = 0x8823;

	private QCOMWriteonlyRendering() {}
}
