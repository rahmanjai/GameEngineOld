/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTShadowSamplers {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameterf, TexParameteri,
	 *  TexParameterfv, TexParameteriv, GetTexParameterfv, and GetTexParameteriv:
	 */
	public static final int GL_TEXTURE_COMPARE_MODE_EXT = 0x884C,
		GL_TEXTURE_COMPARE_FUNC_EXT = 0x884D;

	/**
	 *  Accepted by the &lt;param&gt; parameter of TexParameterf, TexParameteri,
	 *  TexParameterfv, and TexParameteriv when the &lt;pname&gt; parameter is
	 *  TEXTURE_COMPARE_MODE_EXT:
	 */
	public static final int GL_COMPARE_REF_TO_TEXTURE_EXT = 0x884E;

	private EXTShadowSamplers() {}
}
