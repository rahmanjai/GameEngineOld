/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDDeviceMemoryFlags {

	/**
	 * Alloc from GPU's CPU visible heap. 
	 */
	public static final int CL_MEM_USE_PERSISTENT_MEM_AMD = 0x40;

	private AMDDeviceMemoryFlags() {}
}
