/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBShadowAmbient {

	public static final int GL_TEXTURE_COMPARE_FAIL_VALUE_ARB = 0x80BF;

	private ARBShadowAmbient() {}
}
